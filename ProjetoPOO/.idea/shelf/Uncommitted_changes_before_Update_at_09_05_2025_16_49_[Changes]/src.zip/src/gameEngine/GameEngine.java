package gameEngine;

import collisions.Colisor;
import collisions.Point;
import gameEngine.object.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * This class represents a various gameObjects in an arrayList
 * @author Ricardo Rodrigues
 * @author Rodrigo Linhas
 * @author Tiago Tome
 * @version March 27, 2025
 */
public class GameEngine implements IGameEngine {
    private final ArrayList<GameObject> loadedObjects;
    private final ArrayList<IGameObject> enableObjects;
    private final ArrayList<IGameObject> disableObjects;

    /**
     * Construtor of GameEngine
     */
    public GameEngine() {
        this.loadedObjects = new ArrayList<>();
        this.enableObjects = new ArrayList<>();
        this.disableObjects = new ArrayList<>();
    }

    /**
     * Method do add gameObjects to arrayList
     * @param gameObject
     */
    public void add(GameObject gameObject) {
        loadedObjects.add(gameObject);
    }

    /**
     * Method do remove gameObjects from arrayList
     * @param gameObject
     */
    public void destroy(GameObject gameObject) {
        if (gameObject == null) return;
        loadedObjects.remove(gameObject);
    }

    /**
     * Response method to give the ArrayList of gameObjects.
     * @return the List of gameObjets in engine
     */
    public ArrayList<GameObject> getLoadedObjects() {return loadedObjects;}

    /**
     * Adiciona um GameObject à lista de objetos habilitados (ativos no jogo).
     * @param gameObject GameObject a ser ativado.
     * @pre gameObject != null
     * @post GameObject é atualizado e verifica colisões.
     */
    @Override
    public void addEnabled(IGameObject gameObject) {
        if (gameObject != null){
            enableObjects.add(gameObject);
            this.checkCollisions();
        }
    }

    /**
     * Adiciona um GameObject à lista de objetos desabilitados (inativos).
     * @param gameObject GameObject a ser desativado.
     * @pre gameObject != null
     * @post GameObject não é mais atualizado.
     */
    @Override
    public void addDisabled(IGameObject gameObject) {
        if (gameObject != null){
            disableObjects.add(gameObject);
        }
    }

    /**
     * Habilita um GameObject previamente desabilitado.
     * @param gameObject GameObject a ser reativado.
     * @pre gameObject está em disabledObjects
     * @post GameObject é movido para enabledObjects
     */
    @Override
    public void enable(IGameObject gameObject) {
        if (gameObject != null && this.isDisabled(gameObject)){
            disableObjects.remove(gameObject);
            enableObjects.add(gameObject);
        }
    }

    /**
     * Desabilita um GameObject ativo.
     * @param gameObject GameObject a ser desativado.
     * @pre gameObject está em enabledObjects
     * @post GameObject é movido para disabledObjects
     */
    @Override
    public void disable(IGameObject gameObject) {
        if (gameObject != null && this.isEnabled(gameObject)) {
            enableObjects.remove(gameObject);
            disableObjects.add(gameObject);
        }
    }

    /**
     * Verifica se um GameObject está ativo.
     * @param gameObject GameObject a ser verificado.
     * @return true se o objeto está em enabledObjects.
     */
    @Override
    public boolean isEnabled(IGameObject gameObject) {
        for (IGameObject iGameObject : enableObjects) {
            if (iGameObject.equals(gameObject)) return true;
        }
        return false;
    }

    /**
     * Verifica se um GameObject está inativo.
     * @param gameObject GameObject a ser verificado.
     * @return true se o objeto está em disabledObjects.
     */
    @Override
    public boolean isDisabled(IGameObject gameObject) {
        for (IGameObject iGameObject : disableObjects) {
            if (iGameObject.equals(gameObject)) return true;
        }
        return false;
    }

    /**
     * Retorna todos os GameObjects ativos.
     * @return Lista de objetos em enabledObjects.
     */
    @Override
    public List<IGameObject> getEnabled() {
        return enableObjects;
    }

    /**
     * Retorna todos os GameObjects inativos.
     * @return Lista de objetos em disabledObjects.
     */
    @Override
    public List<IGameObject> getDisabled() {
        return disableObjects;
    }

    /**
     * Destroy IGameObject gameObject whether it is enabled or disabled
     * @pre: gameObject != null
     * @pos: gameObject.onDestroy()
     *
     * @param gameObject
     */
    @Override
    public void destroy(IGameObject gameObject) {
        if (gameObject != null) {
            gameObject.behaviour().onDestroy();
        }
    }

    /**
     * Destroy all IGameObjects
     * @pos: calls onDesttoy for each IGameObject
     */
    @Override
    public void destroyAll() {
        loadedObjects.clear();
    }
    /**
     * Manipula a transform
     * Generates a new frame:
     * Get user input from Ul
     * update all the enabled GameObjects
     * check collisions and send info to GameObjects
     * update Ul
     * @pos: Ul.input() &&
     * calls Behaviour.onUpdate() for all enabled objects && Behaviour.checkCollisions() &&
     * Ul.draw()
     */
    @Override
    public void run() {

    }

    /**
     * Check collisions for all the enabled objects
     * @pos: calls Behaviour.onCollision(goI) for all enabled GameObjects passing in the list of all the objects that
     * collided with each IGameObject
     */
    @Override
    public void checkCollisions() {
        for (IGameObject iGameObject : enableObjects) {
            iGameObject.behaviour().onCollision(enableObjects);
        }
    }

    /**
     * Retorna um GameObject aleatório que satisfaz um predicado.
     * @param predicate Condição para filtrar objetos.
     * @return GameObject aleatório ou null se nenhum for encontrado.
     */
    public @Nullable GameObject randomObject(Predicate<GameObject> predicate) {
        List<GameObject> list = loadedObjects.stream().filter(predicate).toList();
        if (list.isEmpty()) return null;
        return list.get(Client.RANDOM.nextInt(list.size()));
    }

    /**
     * Verifica se um GameObject foi destruído.
     * @param iGameObject Objeto a ser verificado.
     * @return true se o objeto foi destruído (implementação temporária).
     */
    public boolean isDestroyed(IGameObject iGameObject) {
        for (IGameObject iGo : loadedObjects) {
            if (iGo.equals(iGameObject)) {return false;}
        }
        return true;
    }

    @SuppressWarnings("DataFlowIssue")
    public boolean checkSolidCollisionAt(Point point) {
        for (GameObject o : loadedObjects)
            if (o instanceof Solid s && ((Colisor) s.collider()).contains(point))
                return true;
        return false;
    }

    public Score getScoreObject(){
        return (Score) loadedObjects.stream()
                .filter(obj -> obj.name().equals("Score"))
                .findFirst()
                .orElseThrow();
    }

    public Lives getLivesObject() {
        return (Lives) loadedObjects.stream()
                .filter(obj -> obj.name().equals("Lives"))
                .findFirst()
                .orElseThrow();
    }
}
