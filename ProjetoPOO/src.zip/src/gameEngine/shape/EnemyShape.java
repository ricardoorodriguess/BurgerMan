package gameEngine.shape;

import gameEngine.object.Collectible;
import gameEngine.object.Enemy;

import java.awt.*;

public class EnemyShape extends Shape {
    public EnemyShape(Enemy enemy) {
        super(enemy);
    }

    @Override
    public void render(Graphics2D g) {

    }
}
