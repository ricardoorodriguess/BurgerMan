package gameEngine.shape;

import gameEngine.object.Lives;
import gameEngine.object.Player;

import java.awt.*;

public class LivesShape extends Shape {
    public LivesShape(Lives lives) {
        super(lives);
    }

    @Override
    public void render(Graphics2D g) {

    }
}
