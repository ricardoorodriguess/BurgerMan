package gameEngine.shape;

import gameEngine.object.Lives;
import gameEngine.object.Score;

import java.awt.*;

public class ScoreShape extends Shape {
    public ScoreShape(Score score) {
        super(score);
    }

    @Override
    public void render(Graphics2D g) {

    }
}
