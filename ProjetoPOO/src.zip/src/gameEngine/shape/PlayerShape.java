package gameEngine.shape;

import gameEngine.object.Player;

import java.awt.*;

public class PlayerShape extends Shape {
    public PlayerShape(Player player) {
        super(player);
    }

    @Override
    public void render(Graphics2D g) {

    }
}
