package gameEngine.shape;

import gameEngine.object.Score;
import gameEngine.object.Solid;

import java.awt.*;

public class SolidShape extends Shape {
    public SolidShape(Solid solid) {
        super(solid);
    }

    @Override
    public void render(Graphics2D g) {

    }
}
