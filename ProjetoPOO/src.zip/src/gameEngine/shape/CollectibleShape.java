package gameEngine.shape;

import gameEngine.object.Collectible;

import java.awt.*;
import java.awt.image.BufferedImage;

public class CollectibleShape extends Shape {
    private BufferedImage image;

    public CollectibleShape(Collectible collectible) {
        super(collectible);

    }

    @Override
    public void render(Graphics2D g) {
        switch (((Collectible)this.igameObject).getType())
        {
            case POINT -> {
                int diameter = 10;
                g.setColor(Color.RED);
                g.fillOval(-diameter/2, -diameter/2, diameter, diameter);
            }
            case TOMATO -> {}
        }


    }
}
