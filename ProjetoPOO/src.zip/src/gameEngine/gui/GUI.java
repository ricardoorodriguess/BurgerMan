package gameEngine.gui;

import gameEngine.Client;
import gameEngine.behaviour.PlayerBehaviour;
import gameEngine.object.IGameObject;
import gameEngine.shape.IShape;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * This class represents the GUI of the game Burger Man
 * @author Ricardo Rodrigues
 * @author Rodrigo Linhas
 * @author Tiago Tome
 * @version May 17, 2025
 */
public class GUI extends JFrame implements IGUI {
    public final CopyOnWriteArrayList<InputEvent> queue;
    private final GamePanel gamePanel;

    /**
     * Constructor of the GUI class.
     * Initializes the input event queue using CopyOnWriteArrayList
     * to ensure thread safety in concurrent environments.
     */
    public GUI(List<IGameObject> gameObjects) {
        super("Hamburger-Man");
        queue = new CopyOnWriteArrayList<>();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(672, 744);
        setLocationRelativeTo(null); // Center the window on the screen
        setResizable(false);

        gamePanel = new GamePanel(gameObjects);
        setContentPane(gamePanel);
        setBackground(Color.BLACK);
        setIconImage(new ImageIcon(Objects.requireNonNull(getClass().getResource("/images/burgerUp.png"))).getImage());
        setVisible(true);

        addKeyListener();
    }

    public void refresh() {
        SwingUtilities.invokeLater(() -> gamePanel.repaint());
    }

    @Override
    public @Nullable InputEvent dequeue() {
        try {
            InputEvent ie = queue.removeFirst();
            //System.out.println(ie);
            return ie;
        } catch (Exception _) {
            return null;
        }
    }

    /*
    @Override
    public void display(@NotNull List<IGameObject> list, Graphics graphics) {
        //setContentPane(new BackgroundPanel());
        IShape sh;
        for (IGameObject go : list)
            if ((sh = go.shape()) != null)
                sh.draw((Graphics2D) graphics);
    }
    */

    private void addKeyListener() {
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {
                //System.out.println(e);
                //System.out.println(((PlayerBehaviour) Client.ENGINE.getPlayerObject().behaviour()).speed);
                queue.addLast(e);
                //repaint();
            }

            @Override
            public void keyReleased(KeyEvent e) {}
        });
    }

    /*
    @Override
    public void paint(Graphics g) {
        if (this.getBufferStrategy() == null) {
            this.createBufferStrategy(2); // buffer duplo
            return;
        }

        BufferStrategy bs = this.getBufferStrategy();
        Graphics2D g2 = (Graphics2D) bs.getDrawGraphics();
        super.paint(g2);

        //g2.clearRect(0, 0, this.getWidth(), this.getHeight());

        // Renderizar os objetos ativos
        display(Client.ENGINE.getEnabled(), g2);

        g2.dispose();
        bs.show();
    }
     */
}
